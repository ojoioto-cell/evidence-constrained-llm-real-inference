#!/usr/bin/env python3
import argparse
import json
import os
import time
from typing import Dict, Any

from dotenv import load_dotenv
from tqdm import tqdm
from openai import OpenAI

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROMPT_PATH = os.path.join(BASE_DIR, "prompts", "evidence_first_prompt.txt")

def load_prompt_template():
    with open(PROMPT_PATH, "r", encoding="utf-8") as f:
        return f.read()

def load_events(path):
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)

def load_done_ids(path):
    done = set()
    if not os.path.exists(path):
        return done
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                row = json.loads(line)
                done.add(row.get("event_id"))
            except Exception:
                continue
    return done

def parse_json_from_text(text: str) -> Dict[str, Any]:
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            return json.loads(text[start:end+1])
        raise

def call_llm(client, model, temperature, max_tokens, event, prompt_template, retries=3):
    event_for_prompt = {
        "event_id": event["event_id"],
        "log_type": event["log_type"],
        "message": event["message"],
        "obfuscation": event.get("obfuscation"),
        "condition": event.get("condition"),
    }
    prompt = prompt_template.replace("{{EVENT_JSON}}", json.dumps(event_for_prompt, ensure_ascii=False))

    last_error = None
    for attempt in range(retries):
        try:
            response = client.chat.completions.create(
                model=model,
                temperature=temperature,
                max_tokens=max_tokens,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": "You are a cybersecurity log-analysis assistant. Return valid JSON only."},
                    {"role": "user", "content": prompt},
                ],
            )
            text = response.choices[0].message.content
            parsed = parse_json_from_text(text)
            return text, parsed
        except Exception as e:
            last_error = e
            time.sleep(2 ** attempt)
    raise last_error

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default=os.path.join(BASE_DIR, "data", "events.jsonl"))
    parser.add_argument("--output", default=os.path.join(BASE_DIR, "results", "llm_outputs.jsonl"))
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--sleep", type=float, default=0.0)
    args = parser.parse_args()

    load_dotenv(os.path.join(BASE_DIR, ".env"))

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is missing. Set it in .env or environment variables.")

    model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    temperature = float(os.getenv("OPENAI_TEMPERATURE", "0.1"))
    max_tokens = int(os.getenv("OPENAI_MAX_OUTPUT_TOKENS", "512"))

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    prompt_template = load_prompt_template()
    client = OpenAI(api_key=api_key)

    done_ids = load_done_ids(args.output)
    events = list(load_events(args.input))
    if args.limit is not None:
        events = events[:args.limit]

    mode = "a" if os.path.exists(args.output) else "w"
    with open(args.output, mode, encoding="utf-8") as out:
        for event in tqdm(events, desc="LLM inference"):
            if event["event_id"] in done_ids:
                continue
            raw_text, parsed = call_llm(
                client=client,
                model=model,
                temperature=temperature,
                max_tokens=max_tokens,
                event=event,
                prompt_template=prompt_template,
            )
            record = {
                "event_id": event["event_id"],
                "model": model,
                "raw_response": raw_text,
                "parsed": parsed,
            }
            out.write(json.dumps(record, ensure_ascii=False) + "\n")
            out.flush()
            if args.sleep:
                time.sleep(args.sleep)

if __name__ == "__main__":
    main()
