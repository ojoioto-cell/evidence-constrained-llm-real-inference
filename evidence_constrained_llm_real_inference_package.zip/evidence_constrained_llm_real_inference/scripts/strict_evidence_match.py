#!/usr/bin/env python3

def strict_evidence_match(event, llm_output):
    if not llm_output:
        return False
    if int(llm_output.get("intrusion", 0)) != 1:
        return False
    message = event.get("message", "")
    evidence = llm_output.get("evidence", [])
    if not evidence:
        return False
    return all(isinstance(e, str) and e != "" and e in message for e in evidence)
