#!/usr/bin/env python3
import argparse
import csv
import json
import os
from collections import defaultdict

from validator import validate_output
from sanity_check import sanity_check
from strict_evidence_match import strict_evidence_match

ATTACK_TECHNIQUES = ["T1059", "T1190", "T1047", "T1071"]

def load_jsonl(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows

def load_llm_outputs(path):
    outputs = {}
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if not line.strip():
                continue
            row = json.loads(line)
            outputs[row["event_id"]] = row.get("parsed")
    return outputs

def first_tech(obj):
    if not obj:
        return "T0000"
    tech = obj.get("technique", ["T0000"])
    if isinstance(tech, str):
        return tech
    if isinstance(tech, list) and tech:
        return tech[0]
    return "T0000"

def llm_intrusion(obj):
    try:
        return int(obj.get("intrusion", 0))
    except Exception:
        return 0

def predict_for_method(method, event, llm_obj):
    sanity_ok, sanity_tid, _ = sanity_check(event)
    valid, warnings, normalized = validate_output(llm_obj or {}, event=event)

    if method == "Rule-only":
        return 1 if sanity_ok else 0, sanity_tid if sanity_ok else "T0000", valid, sanity_ok, warnings

    if method == "LLM-only":
        pred = llm_intrusion(llm_obj or {})
        return pred, first_tech(llm_obj) if pred else "T0000", valid, sanity_ok, warnings

    if method == "LLM+Validator":
        pred = llm_intrusion(normalized or {}) if valid else 0
        return pred, first_tech(normalized) if pred else "T0000", valid, sanity_ok, warnings

    if method == "LLM+Sanity-Check":
        pred = 1 if llm_intrusion(llm_obj or {}) == 1 and sanity_ok else 0
        return pred, sanity_tid if pred else "T0000", valid, sanity_ok, warnings

    if method == "Full Pipeline":
        sem = strict_evidence_match(event, normalized or {})
        pred = 1 if valid and sanity_ok and sem and llm_intrusion(normalized or {}) == 1 else 0
        return pred, sanity_tid if pred else "T0000", valid, sanity_ok, warnings

    raise ValueError(method)

def binary_metrics(rows):
    tp = sum(1 for r in rows if r["truth_intrusion"] == 1 and r["pred_intrusion"] == 1)
    fp = sum(1 for r in rows if r["truth_intrusion"] == 0 and r["pred_intrusion"] == 1)
    tn = sum(1 for r in rows if r["truth_intrusion"] == 0 and r["pred_intrusion"] == 0)
    fn = sum(1 for r in rows if r["truth_intrusion"] == 1 and r["pred_intrusion"] == 0)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return tp, fp, tn, fn, precision, recall, f1

def macro_f1(rows):
    f1s = []
    for cls in ATTACK_TECHNIQUES:
        tp = sum(1 for r in rows if r["truth_technique"] == cls and r["pred_technique"] == cls)
        fp = sum(1 for r in rows if r["truth_technique"] != cls and r["pred_technique"] == cls)
        fn = sum(1 for r in rows if r["truth_technique"] == cls and r["pred_technique"] != cls)
        p = tp / (tp + fp) if tp + fp else 0.0
        rc = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * p * rc / (p + rc) if p + rc else 0.0
        f1s.append(f1)
    return sum(f1s) / len(f1s)

def classify_error(event, pred_intrusion, valid, sanity_ok, llm_obj):
    if event["intrusion"] == 0 or pred_intrusion == 1:
        return None
    if llm_obj and llm_intrusion(llm_obj) == 1 and not strict_evidence_match(event, llm_obj):
        return "Evidence mismatch"
    if event.get("condition") == "unseen_template":
        return "Unseen template"
    if event.get("obfuscation") == "Hard":
        return "Hard obfuscation"
    if event.get("is_ambiguous"):
        return "Ambiguous label"
    return "Other FN"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--events", required=True)
    parser.add_argument("--llm_outputs", required=True)
    parser.add_argument("--out_dir", default="results")
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    events = load_jsonl(args.events)
    llm_outputs = load_llm_outputs(args.llm_outputs)

    methods = ["Rule-only", "LLM-only", "LLM+Validator", "LLM+Sanity-Check", "Full Pipeline"]
    all_rows = []

    for event in events:
        llm_obj = llm_outputs.get(event["event_id"])
        for method in methods:
            pred_intrusion, pred_technique, valid, sanity_ok, warnings = predict_for_method(method, event, llm_obj)
            all_rows.append({
                "event_id": event["event_id"],
                "method": method,
                "truth_intrusion": int(event["intrusion"]),
                "truth_technique": event["technique"],
                "pred_intrusion": pred_intrusion,
                "pred_technique": pred_technique,
                "obfuscation": event.get("obfuscation"),
                "condition": event.get("condition"),
                "validator_valid": int(bool(valid)),
                "sanity_ok": int(bool(sanity_ok)),
                "validator_warnings": "|".join(warnings or []),
            })

    pred_path = os.path.join(args.out_dir, "method_predictions.csv")
    with open(pred_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(all_rows[0].keys()))
        writer.writeheader()
        writer.writerows(all_rows)

    overall_path = os.path.join(args.out_dir, "overall_metrics.csv")
    confusion_path = os.path.join(args.out_dir, "confusion_matrix.csv")

    with open(overall_path, "w", encoding="utf-8", newline="") as f1, open(confusion_path, "w", encoding="utf-8", newline="") as f2:
        ow = csv.DictWriter(f1, fieldnames=["Method", "Event", "Precision", "Recall", "F1", "Tech_F1"])
        cw = csv.DictWriter(f2, fieldnames=["Method", "TP", "FP", "TN", "FN"])
        ow.writeheader()
        cw.writeheader()
        for method in methods:
            rows = [r for r in all_rows if r["method"] == method]
            tp, fp, tn, fn, p, rc, f1v = binary_metrics(rows)
            tech_f1 = macro_f1(rows)
            ow.writerow({"Method": method, "Event": len(events), "Precision": f"{p:.4f}", "Recall": f"{rc:.4f}", "F1": f"{f1v:.4f}", "Tech_F1": f"{tech_f1:.4f}"})
            cw.writerow({"Method": method, "TP": tp, "FP": fp, "TN": tn, "FN": fn})

    obf_path = os.path.join(args.out_dir, "obfuscation_metrics.csv")
    with open(obf_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["Obfuscation", "Method", "Attack_events", "Binary_Recall", "Tech_F1"])
        writer.writeheader()
        for obf in ["None", "Easy", "Medium", "Hard"]:
            for method in ["LLM-only", "LLM+Sanity-Check", "Full Pipeline"]:
                rows = [r for r in all_rows if r["method"] == method and r["obfuscation"] == obf and r["truth_intrusion"] == 1]
                if not rows:
                    continue
                tp = sum(1 for r in rows if r["pred_intrusion"] == 1)
                recall = tp / len(rows)
                tech_f1 = macro_f1(rows)
                writer.writerow({"Obfuscation": obf, "Method": method, "Attack_events": len(rows), "Binary_Recall": f"{recall:.4f}", "Tech_F1": f"{tech_f1:.4f}"})

    err_counts = defaultdict(int)
    for event in events:
        if event["intrusion"] != 1:
            continue
        llm_obj = llm_outputs.get(event["event_id"])
        pred_intrusion, _, valid, sanity_ok, _ = predict_for_method("Full Pipeline", event, llm_obj)
        err = classify_error(event, pred_intrusion, valid, sanity_ok, llm_obj)
        if err:
            err_counts[err] += 1

    error_path = os.path.join(args.out_dir, "error_analysis.csv")
    cause_fix = {
        "Evidence mismatch": ("String mismatch", "normalization, fuzzy matching"),
        "Other FN": ("Final confirmation failure", "soft validation"),
        "Unseen template": ("Out-of-template variant", "template augmentation"),
        "Hard obfuscation": ("Obfuscation matching failure", "decoding, token normalization"),
        "Ambiguous label": ("Candidate technique confusion", "Top-k scoring"),
    }
    with open(error_path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["Error_type", "Count", "Cause", "Fix"])
        writer.writeheader()
        for k, v in sorted(err_counts.items(), key=lambda x: -x[1]):
            cause, fix = cause_fix.get(k, ("Unknown", "Review"))
            writer.writerow({"Error_type": k, "Count": v, "Cause": cause, "Fix": fix})

    print(f"Wrote {overall_path}")
    print(f"Wrote {confusion_path}")
    print(f"Wrote {obf_path}")
    print(f"Wrote {error_path}")
    print(f"Wrote {pred_path}")

if __name__ == "__main__":
    main()
