#!/usr/bin/env python3
import csv
import json
import os
import random

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

SEED = 260615
random.seed(SEED)

ATTACK_OBF_COUNTS = {
    "None": 1033,
    "Easy": 1209,
    "Medium": 648,
    "Hard": 710,
}
BENIGN_COUNT = 1200

TECHNIQUES = [
    ("T1059", "TA0002", "edr_powershell"),
    ("T1190", "TA0001", "waf"),
    ("T1047", "TA0002", "edr_wmic"),
    ("T1071", "TA0011", "proxy"),
]

def attack_message(log_type, obf, n):
    if log_type == "edr_powershell":
        return {
            "None": "powershell.exe -enc SQBFAFgA IEX download cradle",
            "Easy": "PowerShell.EXE -e SQBFAFgA invoke expression",
            "Medium": "powershell.exe -EncodedCommand UABvAHcAZQBy with inserted spaces",
            "Hard": "po^wer^shell . exe -e<n>c fragmented encoded command"
        }[obf]
    if log_type == "waf":
        return {
            "None": "GET /index.php?id=1 UNION SELECT password FROM users",
            "Easy": "GET /item?id=1 union select user from account",
            "Medium": "GET /search?q=%55%4e%49%4f%4e/**/SELECT",
            "Hard": "GET /a/../b?q=UN//ION%2520SEL//ECT path split"
        }[obf]
    if log_type == "edr_wmic":
        return {
            "None": "wmic.exe process call create cmd.exe /c whoami",
            "Easy": "WMIC process call create powershell -nop",
            "Medium": "wmic.exe process call create encoded child process",
            "Hard": "w m i c process/call/create fragmented remote execution"
        }[obf]
    return {
        "None": "POST /upload artifact=exfil bytes_out=20480",
        "Easy": "POST /put artifact=c2 user_agent=Mozilla",
        "Medium": "POST /up%6coad artifact=tunnel long_session=true",
        "Hard": "POST /up/../load artifact=ex%66il chunked transfer"
    }[obf]

def benign_message(i):
    samples = [
        "GET /help/union-meeting-notes status=200",
        "powershell.exe Get-Process signed_admin_task=true",
        "wmic.exe qfe get hotfixid maintenance=true",
        "POST /upload-profile artifact=none bytes_out=2048",
        "GET /index.html normal browsing event"
    ]
    return samples[i % len(samples)]

def condition_for_attack(obf, i):
    if i % 11 == 0:
        return "ambiguous_candidate"
    if i % 7 == 0:
        return "unseen_template"
    if obf == "Hard":
        return "hard_obfuscation"
    return "seen_template"

def candidate_techniques(primary, condition):
    if condition == "ambiguous_candidate":
        if primary == "T1059":
            return ["T1059", "T1047"]
        if primary == "T1190":
            return ["T1190", "T1071"]
        if primary == "T1047":
            return ["T1047", "T1059"]
        return ["T1071", "T1190"]
    return [primary]

def main():
    events = []
    event_id = 1

    for obf, count in ATTACK_OBF_COUNTS.items():
        for i in range(count):
            technique, tactic, log_type = TECHNIQUES[(event_id - 1) % len(TECHNIQUES)]
            condition = condition_for_attack(obf, i)
            event = {
                "event_id": f"evt_{event_id:05d}",
                "log_type": log_type,
                "message": attack_message(log_type, obf, event_id),
                "intrusion": 1,
                "technique": technique,
                "tactic": tactic,
                "obfuscation": obf,
                "condition": condition,
                "template_type": "unseen" if condition == "unseen_template" else "seen",
                "is_ambiguous": condition == "ambiguous_candidate",
                "candidate_techniques": candidate_techniques(technique, condition)
            }
            events.append(event)
            event_id += 1

    for i in range(BENIGN_COUNT):
        event = {
            "event_id": f"evt_{event_id:05d}",
            "log_type": ["waf", "edr_powershell", "edr_wmic", "proxy"][i % 4],
            "message": benign_message(i),
            "intrusion": 0,
            "technique": "T0000",
            "tactic": "TA0000",
            "obfuscation": "Benign",
            "condition": "benign_near_miss" if i % 3 == 0 else "benign",
            "template_type": "benign",
            "is_ambiguous": False,
            "candidate_techniques": []
        }
        events.append(event)
        event_id += 1

    events_path = os.path.join(DATA_DIR, "events.jsonl")
    labels_path = os.path.join(DATA_DIR, "labels.csv")

    with open(events_path, "w", encoding="utf-8") as f:
        for event in events:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")

    with open(labels_path, "w", encoding="utf-8", newline="") as f:
        fields = ["event_id", "intrusion", "technique", "tactic", "obfuscation", "condition", "template_type", "is_ambiguous", "candidate_techniques"]
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for event in events:
            row = {field: event[field] for field in fields}
            row["candidate_techniques"] = "|".join(event["candidate_techniques"])
            writer.writerow(row)

    print(f"Wrote {len(events)} events to {events_path}")
    print(f"Wrote labels to {labels_path}")

if __name__ == "__main__":
    main()
