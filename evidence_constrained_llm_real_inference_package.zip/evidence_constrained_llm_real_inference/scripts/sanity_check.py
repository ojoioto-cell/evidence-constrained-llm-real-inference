#!/usr/bin/env python3

def sanity_check(event):
    msg = event.get("message", "")
    low = msg.lower()
    log_type = event.get("log_type", "")

    if log_type == "waf":
        if any(t in low for t in ["union", "1=1", "../", "/etc/passwd", "etc/passwd"]):
            return True, "T1190", "waf_rule"

    if log_type == "edr_powershell":
        if "powershell" in low and any(t in low for t in ["-enc", "-e", "encodedcommand", "iex"]):
            return True, "T1059", "powershell_rule"

    if log_type == "edr_wmic":
        if "wmic" in low and "process" in low and "create" in low:
            return True, "T1047", "wmic_rule"

    if log_type == "proxy":
        if any(t in low for t in ["/tunnel", "/upload", "/put", "c2", "exfil", "tunnel"]):
            return True, "T1071", "proxy_rule"

    return False, "T0000", "no_match"
