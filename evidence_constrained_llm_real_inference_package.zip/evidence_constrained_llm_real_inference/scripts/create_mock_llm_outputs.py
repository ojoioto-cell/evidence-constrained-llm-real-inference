#!/usr/bin/env python3
"""
Offline smoke-test helper.

This script creates mock LLM outputs from ground-truth labels.
Use it only to test the pipeline without spending API credits.
It is not the actual LLM experiment.
"""
import argparse
import json
import os

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/events.jsonl")
    parser.add_argument("--output", default="results/llm_outputs_mock.jsonl")
    args = parser.parse_args()

    os.makedirs(os.path.dirname(args.output), exist_ok=True)

    with open(args.input, "r", encoding="utf-8") as fin, open(args.output, "w", encoding="utf-8") as fout:
        for line in fin:
            e = json.loads(line)
            evidence = []
            msg = e["message"]
            for tok in ["powershell", "-enc", "-e", "IEX", "UNION", "union", "wmic", "process", "create", "/upload", "/put", "exfil", "c2", "tunnel"]:
                if tok in msg:
                    evidence.append(tok)
                    break
            if e["intrusion"] == 0:
                parsed = {"event_id": e["event_id"], "intrusion": 0, "technique": ["T0000"], "tactic": ["TA0000"], "evidence": [], "confidence": 0.10}
            else:
                parsed = {"event_id": e["event_id"], "intrusion": 1, "technique": [e["technique"]], "tactic": [e["tactic"]], "evidence": evidence or [msg[:20]], "confidence": 0.85}
            fout.write(json.dumps({"event_id": e["event_id"], "model": "mock", "raw_response": json.dumps(parsed), "parsed": parsed}, ensure_ascii=False) + "\n")
    print(f"Wrote {args.output}")

if __name__ == "__main__":
    main()
