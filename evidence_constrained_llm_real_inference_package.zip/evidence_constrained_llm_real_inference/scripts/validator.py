#!/usr/bin/env python3
import re

ALLOWED = {
    "T1059": {"TA0002"},
    "T1190": {"TA0001"},
    "T1047": {"TA0002"},
    "T1071": {"TA0011"},
    "T0000": {"TA0000"},
}

REQUIRED = ["event_id", "intrusion", "technique", "tactic", "evidence", "confidence"]

def normalize_llm_output(obj):
    if not isinstance(obj, dict):
        return None
    out = dict(obj)
    if isinstance(out.get("technique"), str):
        out["technique"] = [out["technique"]]
    if isinstance(out.get("tactic"), str):
        out["tactic"] = [out["tactic"]]
    if not isinstance(out.get("evidence", []), list):
        out["evidence"] = [str(out.get("evidence"))]
    return out

def validate_output(obj, event=None):
    warnings = []
    obj = normalize_llm_output(obj)
    if obj is None:
        return False, ["not_json_object"], None

    for field in REQUIRED:
        if field not in obj:
            return False, [f"missing_field:{field}"], obj

    try:
        obj["intrusion"] = int(obj["intrusion"])
    except Exception:
        return False, ["invalid_intrusion_type"], obj

    if obj["intrusion"] not in (0, 1):
        return False, ["invalid_intrusion_value"], obj

    try:
        obj["confidence"] = float(obj["confidence"])
    except Exception:
        warnings.append("invalid_confidence_type")
        obj["confidence"] = 0.0

    if obj["intrusion"] == 1 and len(obj.get("evidence", [])) == 0:
        return False, ["missing_evidence_for_intrusion"], obj

    techniques = obj.get("technique", [])
    tactics = obj.get("tactic", [])
    if not isinstance(techniques, list) or not isinstance(tactics, list):
        return False, ["invalid_technique_or_tactic_type"], obj

    for tech in techniques:
        if tech not in ALLOWED:
            warnings.append(f"unknown_technique:{tech}")
            continue
        if not set(tactics).intersection(ALLOWED[tech]):
            warnings.append(f"technique_tactic_mismatch:{tech}")

    if event is not None and obj["intrusion"] == 1:
        msg = event.get("message", "")
        for ev in obj.get("evidence", []):
            if ev and ev not in msg:
                warnings.append(f"evidence_not_exact_substring:{ev}")

    return True, warnings, obj
