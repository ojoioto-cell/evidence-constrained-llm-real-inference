# Paper Alignment

This package aligns with the manuscript as follows.

## Manuscript Section 3

- JSONL normalization: `data/events.jsonl`
- Evidence-first prompt: `prompts/evidence_first_prompt.txt`
- Validator: `scripts/validator.py`
- Sanity-Check: `scripts/sanity_check.py`
- Strict evidence matching: `scripts/strict_evidence_match.py`

## Manuscript Section 4

- Dataset configuration: `scripts/generate_synthetic_logs.py`
- LLM model configuration: `.env.example`
- LLM inference: `scripts/run_llm_inference.py`
- Evaluation protocol: `scripts/evaluate_pipeline.py`

## Manuscript Section 5

- Overall metrics: `results/overall_metrics.csv`
- Confusion matrix: `results/confusion_matrix.csv`
- Obfuscation metrics: `results/obfuscation_metrics.csv`
- Error analysis: `results/error_analysis.csv`

## Important

Running the actual LLM inference may produce values that differ from the manuscript due to API/model updates and nondeterministic serving behavior. Store `results/llm_outputs.jsonl` to preserve an exact run.
