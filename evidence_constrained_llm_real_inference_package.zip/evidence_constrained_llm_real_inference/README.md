# Evidence-Constrained LLM Security Log Analysis - Real LLM Inference Reproduction Package

This repository provides a reproducible implementation for the paper:

**Evidence-Constrained LLM-Based Security Log Analysis and MITRE ATT&CK Mapping**

## What This Package Provides

This package includes:

- Synthetic/anonymized JSONL evaluation data
- Evidence-first prompt template
- Actual OpenAI API LLM inference script
- Validator implementation
- Sanity-Check implementation
- Strict evidence matching implementation
- Rule-only / LLM-only / LLM+Validator / LLM+Sanity-Check / Full Pipeline evaluation
- Metrics export scripts

## Important Disclosure

This repository does **not** include raw operational security logs. Raw security logs may contain sensitive information such as IP addresses, user accounts, internal domains, hostnames, system paths, and security-device identifiers.

The included dataset is synthetic/anonymized and is intended to reproduce the evaluation structure described in the paper.

## Paper-Aligned Dataset Structure

The generated dataset contains:

- Total events: 4,800
- Attack events: 3,600
- Benign events: 1,200
- Attack obfuscation levels:
  - None: 1,033
  - Easy: 1,209
  - Medium: 648
  - Hard: 710

Attack labels are distributed across four ATT&CK techniques:

- T1059: Command and Scripting Interpreter
- T1190: Exploit Public-Facing Application
- T1047: Windows Management Instrumentation
- T1071: Application Layer Protocol

Benign or ATT&CK-outside events use the dummy label:

- T0000 / TA0000

## Installation

```bash
python -m venv .venv
source .venv/bin/activate        # Linux/macOS
# .venv\Scripts\activate         # Windows

pip install -r requirements.txt
```

## Configure API Key

Copy `.env.example` to `.env` and set your API key:

```bash
cp .env.example .env
```

Edit `.env`:

```text
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4.1-mini
OPENAI_TEMPERATURE=0.1
OPENAI_MAX_OUTPUT_TOKENS=512
```

Alternatively, export environment variables directly:

```bash
export OPENAI_API_KEY="sk-..."
export OPENAI_MODEL="gpt-4.1-mini"
```

## Quick Start

### 1. Generate Synthetic/Anonymized Data

```bash
python scripts/generate_synthetic_logs.py
```

This creates:

```text
data/events.jsonl
data/labels.csv
```

### 2. Run Actual LLM Inference

Run a small smoke test first:

```bash
python scripts/run_llm_inference.py --input data/events.jsonl --output results/llm_outputs.jsonl --limit 20
```

Run the full 4,800-event inference:

```bash
python scripts/run_llm_inference.py --input data/events.jsonl --output results/llm_outputs.jsonl
```

The script supports resume. If `results/llm_outputs.jsonl` already contains outputs for some event IDs, they are skipped.

### 3. Evaluate All Five Configurations

```bash
python scripts/evaluate_pipeline.py \
  --events data/events.jsonl \
  --llm_outputs results/llm_outputs.jsonl \
  --out_dir results
```

Generated outputs:

```text
results/overall_metrics.csv
results/confusion_matrix.csv
results/obfuscation_metrics.csv
results/error_analysis.csv
results/method_predictions.csv
```

## Compared Methods

1. **Rule-only**  
   Uses only rule-based evidence matching.

2. **LLM-only**  
   Uses the raw structured LLM output.

3. **LLM+Validator**  
   Uses LLM output after JSON schema and ATT&CK consistency validation.

4. **LLM+Sanity-Check**  
   Combines LLM intrusion prediction with log-type-specific evidence rules.

5. **Full Pipeline**  
   Requires Validator + Sanity-Check + strict evidence matching.  
   This is a strict variant for analyzing the recall degradation caused by hard-gate validation.

## Reproducibility Notes

LLM output may vary due to model updates, API backend changes, or nondeterministic serving behavior. The paper used:

- model: `gpt-4.1-mini`
- temperature: `0.1`
- max output tokens: `512`
- first response only

To preserve reproducibility, this package stores the raw LLM response, parsed JSON output, validation status, sanity-check result, final predictions, and evaluation metrics.

## Data Release Policy

Raw operational logs are not disclosed. Synthetic/anonymized logs are provided for review and reproduction. If this repository is used with real logs, users must anonymize sensitive fields before sending data to external LLM APIs.
